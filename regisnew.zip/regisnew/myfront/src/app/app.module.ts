import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { NavbarComponent } from './component/navbar/navbar.component';
import { LoginComponent } from './component/login/login.component';

import { HttpClientModule } from '@angular/common/http';
import { EdittodoComponent } from './component/edittodo/edittodo.component';

import { ListtodoComponent } from './component/listtodo/listtodo.component';
import { AddtodoComponent } from './component/addtodo/addtodo.component';

import { RegisterComponent } from './component/register/register.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarComponent,
    LoginComponent,
    
  
    EdittodoComponent,
 
    ListtodoComponent,
 
    AddtodoComponent,
 

 
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
