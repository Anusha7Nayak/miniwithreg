import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Task } from '../model/task';
import { Register } from '../model/reg';

@Injectable({
  providedIn: 'root'
})
export class TaskService {
  baseUrl: string = "   http://localhost:800/tasks";
  reg:string="  http://localhost:800/register";

  getTasks(){
   return this.http.get<Task[]>(this.baseUrl);
  }
  getUser(){
    return this.http.get<Register[]>(this.reg);
  }
  deletetask(id:number){
    return this.http.delete(this.baseUrl+ "/"+id)
  }
  createtask(task:Task){
    return this.http.post(this.baseUrl,task);  
  }
  register(user: Register) {
    return this.http.post(this.reg+"/", user);
}
  edittask(task: Task){
    return this.http.put(this.baseUrl+ '/' + task.id, task);
   }
   getTasksById(id:number){
    return this.http.get<Task>(this.baseUrl+ "/"+id)
  }
  constructor(private http:HttpClient){}
}