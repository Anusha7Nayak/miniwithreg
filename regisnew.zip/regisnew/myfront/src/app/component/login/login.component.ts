import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Register } from 'src/app/model/reg';
import { TaskService } from 'src/app/services/task.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
userarray:Register[];
  loginForm: FormGroup;

  submitted: boolean = false;
  
  invalidLogin: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router,private taskservice:TaskService) { }
 
   
  onSubmit() {
    this.submitted = true;
    // If validation failed, it should return to Validate again
    if (this.loginForm.invalid) {
      return;
    }

    let username= this.loginForm.controls.username.value;
    
    let password=this.loginForm.controls.password.value;
    
   
    for(let i=0;i<this.userarray.length;i++){
      if(this.loginForm.controls.username.value==this.userarray[i].username
         && this.loginForm.controls.password.value==this.userarray[i].password)
        {
          localStorage.setItem("username",username)
  
          
          this.router.navigate(['todo']);

        }
        
    }
   

      //alert(flag)
  
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
     username: ['', Validators.required],
      password: ['', Validators.required]
    });

    this.taskservice.getUser().subscribe(data=>{this.userarray=data})
  }

}


