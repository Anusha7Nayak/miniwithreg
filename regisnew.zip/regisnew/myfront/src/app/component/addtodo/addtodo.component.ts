import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { TaskService } from 'src/app/services/task.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addtodo',
  templateUrl: './addtodo.component.html',
  styleUrls: ['./addtodo.component.css']
})
export class AddtodoComponent implements OnInit {

  
  addForm: FormGroup;
  submitted: boolean = false;
  constructor(private formbuilder: FormBuilder,
    private router: Router,
    private taskservice: TaskService) { }

  ngOnInit() {
    this.addForm = this.formbuilder.group({
      id: [],
      Name: ['', Validators.required] ,
      Status: ['', Validators.required]
    });
  }
  back(){
    this.router.navigate(['todo']);
  }
  onSubmit(){
    this.submitted=true;
    if(this.addForm.invalid){
      return true;
    }
    this.taskservice.createtask(this.addForm.value).subscribe(data=>{alert
      (this.addForm.value.Name +'record added..!')});
      this.router.navigate(['todo']);
  }

}
